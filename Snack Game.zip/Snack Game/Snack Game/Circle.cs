﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Snack_Game
{
    class Circle
    {
        private int p;

        public int X { get; set; }
        public int Y { get; set; }

        public Circle()
        {
            X = 0;
            Y = 0;
        }

        public Circle(int p)
        {
            
            this.p = p;
        }
    }
}
