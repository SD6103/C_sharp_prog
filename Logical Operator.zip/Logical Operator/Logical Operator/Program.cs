﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Logical_Operator
{
    class Program
    {
        static void Main(string[] args)
        {
            int x, y, z;
            Console.WriteLine("Enter value of X,Y & Z :");
            x = Convert.ToInt32(Console.ReadLine());
            y = Convert.ToInt32(Console.ReadLine());
            z = Convert.ToInt32(Console.ReadLine());

            if (x == y && y == z)
            {
                Console.WriteLine("x=y=z");
            }
            Console.ReadLine();
        }
    }
}
