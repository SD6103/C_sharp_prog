﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Combo_Box
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (textBox1.Text != "" && comboBox1.Text != "")
            {
                MessageBox.Show("Welcome");
                clear();
            }
            else
            {
                MessageBox.Show("Enter your Name & Select Your City");
            }
        }

        private void clear()
        {
            textBox1.Text = "";
            comboBox1.SelectedIndex = -1;
            textBox1.Focus();
        }
    }
}
