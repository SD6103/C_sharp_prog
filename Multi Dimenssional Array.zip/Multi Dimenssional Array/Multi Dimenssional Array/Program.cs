﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Multi_Dimenssional_Array
{
    class Program
    {
        static void Main(string[] args)
        {
            string[,] Movies = new string[2, 2]
            {
                {"Spider-Man NWH","Avengers Endgame"},
                {"Justice League","Man Of Steel"}
            };


            foreach (string val1 in Movies)
            {
                Console.WriteLine(val1);
            }
            Console.ReadLine();
        }
    }
}
