﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Print_Upto_N_While_Loop
{
    class Program
    {
        static void Main(string[] args)
        {
            int n, i;
            Console.WriteLine("Enter Value Of N : ");
            n = Convert.ToInt32(Console.ReadLine());

            i = 1;
            while (i <= n)
            {
                Console.WriteLine(i);
                i++;
            }
            Console.ReadLine();
        }
    }
}
