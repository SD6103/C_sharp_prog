﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace One_Dimessional_Array
{
    class Program
    {
        static void Main(string[] args)
        {
            string[] superhero = { "Spider-Man", "Dr.Strange", "Logan", "IronMan", "SuperMan" };
            foreach (string s in superhero)
            {
                Console.WriteLine(s);
            }
            Console.ReadLine();
        }
    }
}
