﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Electricity_Bill
{
    class Program
    {
        static void Main(string[] args)
        {
            int unit, u1 = 0, amt;
            Console.WriteLine("Enter your units : ");
            unit = Convert.ToInt32(Console.ReadLine());
            if (unit >= 1 && unit < 100)
            {
                u1 = unit / 10;
            }
            else if (unit >= 100 && unit < 1000)
            {
                u1 = unit / 100;
            }
            else if (unit >= 1000 && unit < 10000)
            {
                u1 = unit / 1000;
            }
            else if (unit >= 10000 && unit < 100000)
            {
                u1 = unit / 10000;
            }
            switch (u1)
            {
                case 1:
                        amt = unit * 5;
                        Console.WriteLine("total bill is " + amt);
                    break;
                case 2:
                        amt = unit * 6;
                        Console.WriteLine("Total bill is " + amt);
                    break;
                case 3:
                        amt = unit * 7;
                        Console.WriteLine("Total bill is " + amt);
                    break;
                case 4:
                        amt = unit * 8;
                        Console.WriteLine("Total bill is " + amt);
                    break;
                case 5:
                        amt = unit * 9;
                        Console.WriteLine("total bill is " + amt);
                    break;
                case 6:
                        amt = unit * 10;
                        Console.WriteLine("Total bill is " + amt);
                    break;
                case 7:
                    amt = unit * 11;
                    Console.WriteLine("Total bill is " + amt);
                    break;
                case 8:
                    amt = unit * 12;
                    Console.WriteLine("Total bill is " + amt);
                    break;
                case 9:
                    amt = unit * 13;
                    Console.WriteLine("Total bill is " + amt);
                    break;
                case 10:
                    amt = unit * 14;
                    Console.WriteLine("Total bill is " + amt);
                    break;
                case 11:
                    amt = unit * 15;
                    Console.WriteLine("Total bill is " + amt);
                    break;
                case 12:
                    amt = unit * 16;
                    Console.WriteLine("Total bill is " + amt);
                    break;
                default:
                    Console.WriteLine("Inavalid Unit");
                    break;
            }
            Console.ReadLine();
        }
    }
}
