﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Rectangular_Array
{
    class Program
    {
        static void Main(string[] args)
        {
            int[,] numbers = { { 2, 3, 9 }, { 4, 5, 9 }, { 5, 1, 2 } };

            for (int i = 0; i < numbers.GetLength(0); i++)
            {
                Console.Write(" ");

                for (int j = 0; j < numbers.GetLength(1); j++)
                {
                    Console.Write(numbers[i, j] + " ");

                }
                Console.WriteLine();
            }
            Console.ReadLine();
        }
    }
}
