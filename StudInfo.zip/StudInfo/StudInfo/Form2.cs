﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Data.Sql;

namespace StudInfo
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }

        private void clear()
        {
            comboBox1.Text = "";
            textBox1.Text = "";
            textBox2.Text = "";
            textBox3.Text = "";
            textBox4.Text = "";
            textBox5.Text = "";
            textBox6.Text = "";
            textBox7.Text = "";
            textBox8.Text = "";
            comboBox1.Focus();
        }

        private void Form2_Load(object sender, EventArgs e)
        {
            string sql = "select * from studentinfo";
            SqlDataAdapter da = new SqlDataAdapter(sql, Class1.cn);
            DataTable dt = new DataTable();
            da.Fill(dt);

            comboBox1.DataSource = dt;
            comboBox1.DisplayMember = "Id";
        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            int a = Convert.ToInt32(textBox2.Text);
            int b = Convert.ToInt32(textBox3.Text);
            int c = Convert.ToInt32(textBox4.Text);
            int d = Convert.ToInt32(textBox5.Text);
            int tot = a + b + c + d;
            textBox6.Text = tot.ToString();

            int per = tot / 4;
            textBox7.Text = per.ToString();

            if (per < 100 && per >= 70)
                textBox8.Text = "A";
            else if (per < 70 && per >= 60)
                textBox8.Text = "B";
            else if (per < 60 && per >= 50)
                textBox8.Text = "C";
            else if (per < 50 && per >= 40)
                textBox8.Text = "D";
            else
                textBox8.Text = "E";
        }

        private void button2_Click_1(object sender, EventArgs e)
        {
            if (comboBox1.Text != "" && textBox1.Text != "" && textBox2.Text != "" && textBox3.Text != "" && textBox4.Text != "" && textBox5.Text != "" && textBox6.Text != "" && textBox7.Text != "" && textBox8.Text != "")
            {
                string sql = "insert into result values('" + comboBox1.Text + "','" + textBox1.Text + "','" + textBox2.Text + "','" + textBox3.Text + "','" + textBox4.Text + "','" + textBox5.Text + "','" + textBox6.Text + "','" + textBox7.Text + "','" + textBox8.Text + "')";
                SqlDataAdapter da = new SqlDataAdapter(sql, Class1.cn);
                DataTable dt = new DataTable();

                int a = da.Fill(dt);
                if (a >= 0)
                {
                    MessageBox.Show("Data Saved !", "Database", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    clear();
                }
                else
                {
                    MessageBox.Show("Something Missing!", "Database", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    clear();
                }
            }
        }

        private void button3_Click_1(object sender, EventArgs e)
        {
            Form1 f1 = new Form1();
            f1.Show();
            this.Hide();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            clear();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            string ConnectionSting = @"Data Source=.\SQLEXPRESS;AttachDbFilename=F:\sahil\C#\StudInfo\StudInfo\bin\Debug\Studinfo.mdf;Integrated Security=True;Connect Timeout=30;User Instance=True";
            SqlConnection cn = new SqlConnection(ConnectionSting);
            cn.Open();
            string sql = "select * from result";
            SqlCommand cd = new SqlCommand(sql, cn);
            var read = cd.ExecuteReader();
            DataTable dt = new DataTable();
            dt.Load(read);
            dataGridView1.DataSource = dt;
            cn.Close();
        }

    }
}
