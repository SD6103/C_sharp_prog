﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Data.Sql;

namespace StudInfo
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Form1 f1 = new Form1();
            f1.Show();
            this.Hide();
        }

        private void clear()
        {
            textBox1.Text = "";
            textBox2.Text = "";
            textBox3.Text = "";
            textBox4.Text = "";
            textBox5.Text = "";
            textBox6.Text = "";
            label10.Text = "";
            label11.Text = "";
            label12.Text = "";
            textBox1.Focus();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            int a = Convert.ToInt32(textBox3.Text);
            int b = Convert.ToInt32(textBox4.Text);
            int c = Convert.ToInt32(textBox5.Text);
            int d = Convert.ToInt32(textBox6.Text);
            int tot = a + b + c + d;
            label10.Text = tot.ToString();

            int per = tot / 4;
            label11.Text = per.ToString();

            if (per < 100 && per >= 70)
                label12.Text = "A";
            else if (per < 70 && per >= 60)
                label12.Text = "B";
            else if (per < 60 && per >= 50)
                label12.Text = "C";
            else if (per < 50 && per >= 40)
                label12.Text = "D";
            else
                label12.Text = "E";
            
        }

        private void button3_Click(object sender, EventArgs e)
        {
            clear();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            if (textBox1.Text != "" && textBox2.Text != "" && textBox3.Text != "" && textBox4.Text != "" && textBox5.Text != "" && textBox6.Text != "" && label10.Text != "" && label11.Text!="" && label12.Text!="")
            {
                string sql = "insert into result values('" + textBox1.Text + "','" + textBox2.Text + "','" + textBox3.Text + "','" + textBox4.Text + "','" + textBox5.Text + "','" + textBox6.Text + "','" + label10.Text + "','"+label11.Text+"','"+label12.Text+"')";
                SqlDataAdapter da = new SqlDataAdapter(sql, Class1.cn);
                DataTable dt = new DataTable();

                int a = da.Fill(dt);

                if (a >= 0)
                {
                    MessageBox.Show("Data Saved !", "Database", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    clear();
                }
                else
                {
                    MessageBox.Show("Something Missing!", "Database", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    clear();
                }
            }
        }

    }
}
