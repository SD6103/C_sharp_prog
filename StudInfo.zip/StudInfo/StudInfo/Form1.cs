﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.Sql;
using System.Data.SqlClient;

namespace StudInfo
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (textBox1.Text != "" && textBox2.Text != "" && textBox3.Text != "" && textBox4.Text != "" && textBox5.Text != "" && textBox6.Text != "" && comboBox1.Text != "")
            {
                string sql = "insert into studentinfo values('" + textBox1.Text + "','" + textBox2.Text + "','" + textBox3.Text + "','" + textBox4.Text + "','" + textBox5.Text + "','" + textBox6.Text + "','" + comboBox1.Text + "')";
                SqlDataAdapter da = new SqlDataAdapter(sql, Class1.cn);
                DataTable dt = new DataTable();

                int a = da.Fill(dt);

                if (a >= 0)
                {
                    MessageBox.Show("Data Inserted!", "Database", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    clear();
                }
                else
                {
                    MessageBox.Show("Something Missing!", "Database", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    clear();
                }
            }

            else
            {
                MessageBox.Show("Plese enter values Properly!", "Database", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }

        }

        private void clear()
        {
            textBox1.Text = "";
            textBox2.Text = "";
            textBox3.Text = "";
            textBox4.Text = "";
            textBox5.Text = "";
            textBox6.Text = "";
            comboBox1.SelectedIndex = -1;
            textBox1.Focus();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            clear();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Form2 f2 = new Form2();
            f2.Show();
            this.Hide();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            string ConnectionSting = @"Data Source=.\SQLEXPRESS;AttachDbFilename=F:\sahil\C#\StudInfo\StudInfo\bin\Debug\Studinfo.mdf;Integrated Security=True;Connect Timeout=30;User Instance=True";
            SqlConnection cn = new SqlConnection(ConnectionSting);
            cn.Open();
            string sql = "select * from studentinfo";
            SqlCommand cd = new SqlCommand(sql, cn);
            var read = cd.ExecuteReader();
            DataTable dt = new DataTable();
            dt.Load(read);
            dataGridView1.DataSource = dt;
            cn.Close();
            textBox1.Focus();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            string a = "select Id from studentinfo where Id =  '"+textBox1.Text+"'";
            if (textBox1.Text!="" && textBox2.Text!="" && textBox3.Text!="" && textBox4.Text!="" && textBox5.Text!="" && textBox6.Text!="" && comboBox1.Text!="")
            {
                if(textBox1.Text == a)
                {
                    string ConnectionSting = @"Data Source=.\SQLEXPRESS;AttachDbFilename=F:\sahil\C#\StudInfo\StudInfo\bin\Debug\Studinfo.mdf;Integrated Security=True;Connect Timeout=30;User Instance=True";
                    SqlConnection cn = new SqlConnection(ConnectionSting);
                    cn.Open();
                    string Name = textBox2.Text;
                    string Add = textBox3.Text;
                    string Cls = textBox4.Text;
                    string Stream = textBox5.Text;
                    string Sem = textBox6.Text;
                    string City = comboBox1.Text;
                    string sql = "update studentinfo set Name = '" + textBox2.Text + "',Address = '" + textBox3.Text + "', Class = '" + textBox4.Text + "', Steam = '" + textBox5.Text + "',Sem = '" + textBox6.Text + "', City = '" + comboBox1.Text + "' where Name = '"+ Name +"' ,Address = '"+Add+"',Class = '"+Cls+"',Steam = '"+Stream+"', Sem = '"+Sem+"', City = '"+City+ "'";
                    SqlCommand cd = new SqlCommand(sql, cn);
                    cn.Close();
                    MessageBox.Show("Data Updated");
                }
                else
                {
                    MessageBox.Show("There is No Record Please Check Your Id");
                    textBox1.Focus();
                }
            }
            else
            {
                MessageBox.Show("Enter Values");
            }
        }

        private void button6_Click(object sender, EventArgs e)
        {
            string ConnectionSting = @"Data Source=.\SQLEXPRESS;AttachDbFilename=F:\sahil\C#\StudInfo\StudInfo\bin\Debug\Studinfo.mdf;Integrated Security=True;Connect Timeout=30;User Instance=True";
            SqlConnection cn = new SqlConnection(ConnectionSting);
            cn.Open();
            string Id = textBox1.Text;

            string sql = "delele from studentinfo where Id = " + Id;
            SqlCommand cd = new SqlCommand(sql, cn);
            cn.Close();
            MessageBox.Show("Data Deleted !");
            clear();
        }
    }
}
