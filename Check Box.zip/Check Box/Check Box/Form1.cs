﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Check_Box
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (checkBox1.Checked)
            {
                MessageBox.Show("first check box is selected");
            }
            else if (checkBox2.Checked)
            {
                MessageBox.Show("Second Check Box Selected");
            }
            else if (checkBox3.Checked)
            {
                MessageBox.Show("Third Check Box Selected");
            }
            else if (checkBox4.Checked && textBox1.Text != "")
            {
                MessageBox.Show("You Have Entered Other Hobby");
                textBox1.Text = "";
                textBox1.Enabled = false;
            }
            else
            {
                MessageBox.Show("Select At Least One Check Box");
            }
            if (checkBox4.Checked && textBox1.Text != "")
            {
                MessageBox.Show("You Have Entered Other Hobby");
                textBox1.Text = "";
                textBox1.Enabled = false;
            }

            foreach (Control cBox in this.Controls)
            {
                if (cBox is CheckBox)
                {
                    ((CheckBox)cBox).Checked = false;
                }
            }
            
        }

        private void checkBox4_CheckedChanged(object sender, EventArgs e)
        {
            if (((CheckBox)sender).Checked)
            {
                textBox1.Enabled = true;
            }
            else
            {
                textBox1.Enabled = false;
            }
        }

    }
}
