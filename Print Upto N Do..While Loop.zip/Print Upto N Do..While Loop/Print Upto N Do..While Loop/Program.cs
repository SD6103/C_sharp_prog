﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Print_Upto_N_Do._.While_Loop
{
    class Program
    {
        static void Main(string[] args)
        {
            int n, i;
            Console.WriteLine("Enter Value Of N : ");
            n = Convert.ToInt32(Console.ReadLine());
            i = 1;
            do
            {
                Console.WriteLine(i);
                i++;
            }
            while(i<=n);
            Console.ReadLine();
        }
    }
}
