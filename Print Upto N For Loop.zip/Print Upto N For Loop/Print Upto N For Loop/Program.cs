﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Print_Upto_N_For_Loop
{
    class Program
    {
        static void Main(string[] args)
        {
            int n, i;
            Console.WriteLine("Enter Value Of N : ");
            n = Convert.ToInt32(Console.ReadLine());

            for (i = 1; i <= n; i++)
                Console.WriteLine(i);
            Console.ReadLine();
        }
    }
}
