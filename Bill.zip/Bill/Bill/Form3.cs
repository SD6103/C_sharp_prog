﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.Sql;
using System.Data.SqlClient;

namespace Bill
{
    public partial class Form3 : Form
    {
        SqlConnection cn = new SqlConnection(@"Data Source=.\SQLEXPRESS;AttachDbFilename=F:\sahil\C#\Bill\Bill\bin\Debug\Database1.mdf;Integrated Security=True;Connect Timeout=30;User Instance=True");
        public Form3()
        {
            InitializeComponent();
        }

        protected override bool ProcessCmdKey(ref Message msg, Keys keyData)
        {
            if (keyData == Keys.Escape)
            {
                this.Hide();
                Form1 f1 = new Form1();
                f1.Show();
            }
            return base.ProcessCmdKey(ref msg, keyData);
        }

        private void Form3_Load(object sender, EventArgs e)
        {
            string sql = "select * from client";
            SqlDataAdapter da = new SqlDataAdapter(sql, cn);
            DataTable dt = new DataTable();
            da.Fill(dt);

            comboBox1.DataSource = dt;
            comboBox1.DisplayMember = "Meter_no";
        }

        private void comboBox1_TabIndexChanged(object sender, EventArgs e)
        {
            string sql = "select * from bill where Meter_no= '" + comboBox1.Text + "'";
            SqlDataAdapter da = new SqlDataAdapter(sql, cn);
            DataTable dt = new DataTable();
            da.Fill(dt);
 
        }

        private void comboBox2_TextChanged(object sender, EventArgs e)
        {
            string sql ="select * from bill where Meter_no = '"+comboBox1.Text+"' and Month = '"+comboBox2.Text+"'";
            SqlDataAdapter da = new SqlDataAdapter(sql,cn);
            DataTable dt = new DataTable();
            da.Fill(dt);

            if (dt.Rows.Count > 0)
            {
                MessageBox.Show("Record Exists");
            }
            else
            {
                int previous_unit = Convert.ToInt32(textBox1.Text);
                int Current_unit = Convert.ToInt32(textBox2.Text);
                int units = Current_unit - previous_unit;
                int amount = units * 10;
                textBox3.Text = amount.ToString();
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string sql = "insert into bill values('"+comboBox1.Text+"','"+textBox1.Text+"','"+textBox2.Text+"','"+comboBox2.Text+"','"+textBox3.Text+"')";
            SqlDataAdapter da = new SqlDataAdapter(sql, cn);
            DataTable dt = new DataTable();
            da.Fill(dt);

            MessageBox.Show("Bill Generated & Saved");
            
        }

        private void clear()
        {
            comboBox1.SelectedIndex = -1;
            textBox1.Text = "";
            textBox2.Text = "";
            comboBox2.SelectedIndex = -1;
            textBox3.Text = "";
            comboBox1.Focus();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            clear();
        }





    }
}
